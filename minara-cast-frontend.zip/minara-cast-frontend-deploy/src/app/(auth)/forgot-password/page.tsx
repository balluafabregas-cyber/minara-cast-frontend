'use client';

import { useState } from 'react';
import Link from 'next/link';
import { motion } from 'framer-motion';
import api from '@/lib/api';

export default function ForgotPasswordPage() {
  const [email, setEmail] = useState('');
  const [loading, setLoading] = useState(false);
  const [sent, setSent] = useState(false);
  const [error, setError] = useState('');

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError('');
    setLoading(true);
    try {
      await api.post('/auth/forgot-password', { email });
      setSent(true);
    } catch (err: any) {
      setError(err.response?.data?.message || 'Something went wrong. Please try again.');
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="relative flex min-h-screen items-center justify-center bg-hero-gradient px-4 pt-20">
      <div className="bg-islamic-pattern pointer-events-none absolute inset-0 opacity-10" />
      <motion.div initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }} className="glass-card w-full max-w-md text-white">
        <div className="mb-6 text-center">
          <img src="/logo.svg" alt="MINARA CAST" className="mx-auto h-9 w-auto" />
          <p className="mt-2 text-sm text-white/60">Reset your password</p>
        </div>

        {sent ? (
          <div className="text-center">
            <p className="text-sm text-white/80">
              If an account exists for <span className="font-semibold text-gold-400">{email}</span>, a reset
              link has been sent. Check your inbox (and spam folder).
            </p>
            <Link href="/login" className="btn-gold mt-6 inline-flex">Back to Sign In</Link>
          </div>
        ) : (
          <>
            {error && <div className="mb-4 rounded-lg bg-red-500/20 px-4 py-2 text-sm text-red-200">{error}</div>}
            <form onSubmit={handleSubmit} className="space-y-4">
              <input
                type="email"
                required
                placeholder="Your account email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full rounded-xl border border-white/20 bg-white/5 px-4 py-3 text-sm outline-none placeholder:text-white/40 focus:border-gold-400"
              />
              <button type="submit" disabled={loading} className="btn-gold w-full justify-center disabled:opacity-60">
                {loading ? 'Sending...' : 'Send Reset Link'}
              </button>
            </form>
            <p className="mt-6 text-center text-sm text-white/60">
              Remembered your password?{' '}
              <Link href="/login" className="font-semibold text-gold-400 hover:underline">Sign in</Link>
            </p>
          </>
        )}
      </motion.div>
    </div>
  );
}
