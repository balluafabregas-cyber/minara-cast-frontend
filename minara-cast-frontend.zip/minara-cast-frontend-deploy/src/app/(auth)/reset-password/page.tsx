'use client';

import { Suspense, useState } from 'react';
import { useRouter, useSearchParams } from 'next/navigation';
import Link from 'next/link';
import { motion } from 'framer-motion';
import api from '@/lib/api';

function ResetPasswordForm() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const token = searchParams.get('token') || '';

  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [done, setDone] = useState(false);
  const [error, setError] = useState('');

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError('');
    if (password !== confirmPassword) {
      setError('Passwords do not match.');
      return;
    }
    if (!token) {
      setError('Missing or invalid reset link. Please request a new one.');
      return;
    }
    setLoading(true);
    try {
      await api.post('/auth/reset-password', { token, password, confirmPassword });
      setDone(true);
      setTimeout(() => router.push('/login'), 2000);
    } catch (err: any) {
      setError(err.response?.data?.message || 'This reset link is invalid or has expired.');
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="relative flex min-h-screen items-center justify-center bg-hero-gradient px-4 pt-20">
      <div className="bg-islamic-pattern pointer-events-none absolute inset-0 opacity-10" />
      <motion.div initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }} className="glass-card w-full max-w-md text-white">
        <div className="mb-6 text-center">
          <img src="/logo.svg" alt="MINARA CAST" className="mx-auto h-9 w-auto" />
          <p className="mt-2 text-sm text-white/60">Set a new password</p>
        </div>

        {done ? (
          <p className="text-center text-sm text-emerald-300">Password updated. Redirecting you to sign in...</p>
        ) : (
          <>
            {error && <div className="mb-4 rounded-lg bg-red-500/20 px-4 py-2 text-sm text-red-200">{error}</div>}
            {!token && (
              <div className="mb-4 rounded-lg bg-yellow-500/20 px-4 py-2 text-sm text-yellow-100">
                No reset token found in this link. Request a new one from the{' '}
                <Link href="/forgot-password" className="underline">forgot password</Link> page.
              </div>
            )}
            <form onSubmit={handleSubmit} className="space-y-4">
              <input
                type="password"
                required
                placeholder="New password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full rounded-xl border border-white/20 bg-white/5 px-4 py-3 text-sm outline-none placeholder:text-white/40 focus:border-gold-400"
              />
              <input
                type="password"
                required
                placeholder="Confirm new password"
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
                className="w-full rounded-xl border border-white/20 bg-white/5 px-4 py-3 text-sm outline-none placeholder:text-white/40 focus:border-gold-400"
              />
              <button type="submit" disabled={loading} className="btn-gold w-full justify-center disabled:opacity-60">
                {loading ? 'Updating...' : 'Update Password'}
              </button>
            </form>
          </>
        )}
      </motion.div>
    </div>
  );
}

export default function ResetPasswordPage() {
  return (
    <Suspense fallback={<div className="flex min-h-screen items-center justify-center text-white/60">Loading...</div>}>
      <ResetPasswordForm />
    </Suspense>
  );
}
